DROP TABLE IF EXISTS pagamento CASCADE;
DROP TABLE IF EXISTS plano CASCADE;
DROP TABLE IF EXISTS aluno CASCADE;

CREATE TABLE aluno (
    id_al SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    condicao_aluno VARCHAR(20) NOT NULL
);

CREATE TABLE plano (
    id_pla SERIAL PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE pagamento (
    id_pag SERIAL PRIMARY KEY,
    id_al INT NOT NULL,
    id_pla INT NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    condicao_pagamento VARCHAR(20) NOT NULL,
    data_pagamento DATE NOT NULL,
    hora_pagamento TIME NOT NULL,

    FOREIGN KEY (id_al) REFERENCES aluno(id_al) ON DELETE CASCADE,
    FOREIGN KEY (id_pla) REFERENCES plano(id_pla) ON DELETE CASCADE
);

-- Inserindo dados de exemplo
INSERT INTO aluno (nome, telefone, condicao_aluno) VALUES
('João Silva', '(67) 99999-1111', 'Ativo'),
('Maria Santos', '(67) 99999-2222', 'Ativo'),
('Carlos Oliveira', '(67) 99999-3333', 'Bolsista');

INSERT INTO plano (nome, valor) VALUES
('Plano Bronze', 100.00),
('Plano Prata', 120.00),
('Plano Ouro', 150.00);

INSERT INTO pagamento (id_al, id_pla, valor, condicao_pagamento, data_pagamento, hora_pagamento) VALUES
(1, 1, 100.00, 'pago', '2026-06-20', '10:30:00'),
(2, 2, 120.00, 'pendente', '2026-06-25', '14:45:00'),
(3, 3, 150.00, 'atrasado', '2026-06-10', '09:15:00');