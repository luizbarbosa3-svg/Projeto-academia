const API_URL = window.location.origin;

fetch(`${API_URL}/plano`)
  .then(res => {
    if (!res.ok) {
      throw new Error(`Erro HTTP! status: ${res.status}`);
    }
    return res.json();
  })
  .then(dataArray => {
    const tableBody = document.getElementById('table-body');
    
    if (!tableBody) {
      console.error('Elemento table-body não encontrado');
      return;
    }
    
    // Generate HTML strings for rows and cells
    const htmlRows = dataArray.map(item => `
      <tr>
        <td>${item.id_pla}</td>
        <td>${item.nome}</td>
        <td>${item.valor}</td>
      </tr>
    `).join('');
    
    tableBody.innerHTML = htmlRows;
  })
  .catch(error => {
    console.error('Erro ao buscar planos:', error);
    const tableBody = document.getElementById('table-body');
    if (tableBody) {
      tableBody.innerHTML = '<tr><td colspan="3">Erro ao carregar dados</td></tr>';
    }
  });


