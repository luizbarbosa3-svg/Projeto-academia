const express = require('express');

const routes = express.Router();

const db = require('../db/connect');

//GET
routes.get('/', async (req, res) => {
    try {

        const result = await db.query('SELECT * FROM aluno');

        res.status(200).json(result.rows);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            mensagem: 'Erro interno do servidor.'
        });

    }
});

//POST
routes.post('/', async (req, res) => {
    try {

        const {nome, telefone, condicao_aluno} = req.body;

        if(!nome || !telefone || !condicao_aluno){
            return res.status(400).json({
                mensagem: 'Campos não preenchidos'
            });
        }

        const sql = `
            INSERT INTO aluno (nome, telefone, condicao_aluno)
            VALUES ($1, $2, $3)
            RETURNING *
        `;

        const valores = [nome, telefone, condicao_aluno];

        const result = await db.query(sql, valores);

        res.status(201).json(result.rows[0]);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            mensagem: 'Erro interno do servidor.'
        });

    }
});

//PUT
routes.put('/:id_al', async (req, res) => {

    const {id_al} = req.params;

    if(!id_al){
        return res.status(400).json({mensagem: 'id do aluno é obrigatório'});
    }

    const {nome, telefone, condicao_aluno} = req.body;

    if(!nome || !telefone || !condicao_aluno){
        return res.status(400).json({mensagem: 'Campos não preenchidos'});
    }

    const sql = `
        UPDATE aluno
        SET nome = $1 , telefone = $2 , condicao_aluno = $3
        WHERE id_al = $4
        RETURNING *
    `;

    const valores = [nome, telefone, condicao_aluno, id_al];

    const result = await db.query(sql, valores);

    if(result.rows.length === 0){
        return res.status(404).json({mensagem: 'Aluno não encontrado.'});
    }

    res.status(200).json(result.rows[0]);
});

//DELETE
routes.delete('/:id_al', async (req, res) => {

    const {id_al} = req.params;

    if(!id_al){
        return res.status(400).json({mensagem: 'O id do aluno é obrigatório'});
    }

    const sql = `
        DELETE FROM aluno
        WHERE id_al = $1
        RETURNING *
    `;

    const valores = [id_al];

    const result = await db.query(sql, valores);

    if(result.rows.length === 0) {
        return res.status(404).json({mensagem: 'Aluno não encontrado.'});
    }

    res.status(200).json({mensagem: `Aluno com ID ${id_al} foi excluído com sucesso.`});
});

module.exports = routes;