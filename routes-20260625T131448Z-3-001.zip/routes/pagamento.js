const express = require('express');
const routes = express.Router();
const db = require('../db/connect');

//ROTA GET
routes.get('/', async (req, res) => {
    try {

        const result = await db.query('SELECT * FROM pagamento');

        res.status(200).json(result.rows);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            mensagem: 'Erro interno do servidor ao consultar pagamentos.'
        });

    }
});

//JOIN
routes.get('/relatorio', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT
                p.id_pag,
                a.nome AS aluno,
                a.telefone,
                pl.nome AS plano,
                p.valor,
                p.condicao_pagamento,
                p.data_pagamento,
                p.hora_pagamento
            FROM pagamento p
            INNER JOIN aluno a ON p.id_al = a.id_al
            INNER JOIN plano pl ON p.id_pla = pl.id_pla
        `);

        res.status(200).json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensagem: 'Erro interno do servidor ao consultar relatório de pagamentos.'
        });
    }
});

//GROUP BY
routes.get('/app', async (req, res) => {

    const result = await db.query(`
        SELECT
            pl.nome AS plano,
            SUM(p.valor) AS total_arrecadado
        FROM pagamento p
        INNER JOIN plano pl ON p.id_pla = pl.id_pla
        GROUP BY pl.nome
    `);

    res.status(200).json(result.rows);
});

//POST
routes.post('/', async (req, res) => {
    try {

        const {
            id_al,
            id_pla,
            valor,
            condicao_pagamento,
            data_pagamento,
            hora_pagamento
        } = req.body;

        if (
            !id_al ||
            !id_pla ||
            !valor ||
            !condicao_pagamento ||
            !data_pagamento ||
            !hora_pagamento
        ) {
            return res.status(400).json({
                mensagem: 'Campos não preenchidos'
            });
        }

        const sql = `
            INSERT INTO pagamento (
                id_al,
                id_pla,
                valor,
                condicao_pagamento,
                data_pagamento,
                hora_pagamento
            )
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `;

        const valores = [
            id_al,
            id_pla,
            valor,
            condicao_pagamento,
            data_pagamento,
            hora_pagamento
        ];

        const result = await db.query(sql, valores);

        res.status(201).json(result.rows[0]);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            mensagem: 'Erro interno do servidor ao cadastrar pagamento.'
        });

    }
});
//PUT
routes.put('/:id_pag', async (req, res) => {
    try {
        const { id_pag } = req.params;

        if (!id_pag) {
            return res.status(400).json({
                mensagem: 'id do pagamento é obrigatório'
            });
        }

        const {
            id_al,
            id_pla,
            valor,
            condicao_pagamento,
            data_pagamento,
            hora_pagamento
        } = req.body;

        if (
            !id_al ||
            !id_pla ||
            !valor ||
            !condicao_pagamento ||
            !data_pagamento ||
            !hora_pagamento
        ) {
            return res.status(400).json({
                mensagem: 'Campos não preenchidos'
            });
        }

        const sql = `
            UPDATE pagamento
            SET id_al = $1,
                id_pla = $2,
                valor = $3,
                condicao_pagamento = $4,
                data_pagamento = $5,
                hora_pagamento = $6
            WHERE id_pag = $7
            RETURNING *
        `;

        const valores = [
            id_al,
            id_pla,
            valor,
            condicao_pagamento,
            data_pagamento,
            hora_pagamento,
            id_pag
        ];

        const result = await db.query(sql, valores);

        if (result.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Pagamento não encontrado.'
            });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensagem: 'Erro interno do servidor ao atualizar pagamento.'
        });
    }
});

//DELETE
routes.delete('/:id_pag', async (req, res) => {
    try {
        const { id_pag } = req.params;

        if (!id_pag) {
            return res.status(400).json({
                mensagem: 'O id do pagamento é obrigatório'
            });
        }

        const sql = `
            DELETE FROM pagamento
            WHERE id_pag = $1
            RETURNING *
        `;

        const valores = [id_pag];

        const result = await db.query(sql, valores);

        if (result.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Pagamento não encontrado.'
            });
        }

        res.status(200).json({
            mensagem: `Pagamento com ID ${id_pag} foi excluído com sucesso.`
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensagem: 'Erro interno do servidor ao deletar pagamento.'
        });
    }
});

module.exports = routes;