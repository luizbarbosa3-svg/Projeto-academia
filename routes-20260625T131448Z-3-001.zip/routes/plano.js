const express = require('express');

const routes = express.Router();

const db = require('../db/connect');

//GET
routes.get('/', async (req, res) => {
    try {

        const result = await db.query('SELECT * FROM plano');

        res.status(200).json(result.rows);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            mensagem: 'Erro interno do servidor ao consultar planos.'
        });

    }
});

//POST
routes.post('/', async (req, res) => {
    try {

        const {nome, valor} = req.body;

        if(!nome || !valor){
            return res.status(400).json({
                mensagem: 'Campos não preenchidos'
            });
        }

        const sql = `
            INSERT INTO plano (nome, valor)
            VALUES ($1, $2)
            RETURNING *
        `;

        const valores = [nome, valor];

        const result = await db.query(sql, valores);

        res.status(201).json(result.rows[0]);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            mensagem: 'Erro interno do servidor ao cadastrar plano.'
        });

    }
});

//PUT
routes.put('/:id_pla', async (req, res) => {

    const {id_pla} = req.params;

    if(!id_pla){
        return res.status(400).json({mensagem: 'id do plano é obrigatório'});
    }

    const {nome, valor} = req.body;

    if(!nome || !valor){
        return res.status(400).json({mensagem: 'Campos não preenchidos'});
    }

    const sql = `
        UPDATE plano
        SET nome = $1 , valor = $2
        WHERE id_pla = $3
        RETURNING *
    `;

    const valores = [nome, valor, id_pla];

    const result = await db.query(sql, valores);

    if(result.rows.length === 0){
        return res.status(404).json({mensagem: 'Plano não encontrado.'});
    }

    res.status(200).json(result.rows[0]);
});

//DELETE
routes.delete('/:id_pla', async (req, res) => {

    const {id_pla} = req.params;

    if(!id_pla){
        return res.status(400).json({mensagem: 'O id do plano é obrigatório'});
    }

    const sql = `
        DELETE FROM plano
        WHERE id_pla = $1
        RETURNING *
    `;

    const valores = [id_pla];

    const result = await db.query(sql, valores);

    if(result.rows.length === 0) {
        return res.status(404).json({mensagem: 'Plano não encontrado.'});
    }

    res.status(200).json({mensagem: `Plano com ID ${id_pla} foi excluído com sucesso.`});
});

module.exports = routes;    